<?php
require '../config/database.php';
require_admin();
$msg = ''; $msg_type = 'success';
if (isset($_POST['add'])) {
    $pdo->prepare('INSERT INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,created_at) VALUES(?,?,?,?,?,?,?,NOW())')
        ->execute(array((int)$_POST['category'], trim($_POST['kode']), trim($_POST['nama']), max(0,(float)$_POST['harga']), max(0,(float)$_POST['pokok']), max(0,(int)$_POST['stok']), max(0,(int)$_POST['min'])));
    header('Location: products.php?msg=added'); exit;
}
if (isset($_POST['add_stock'])) {
    $id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $jumlah = isset($_POST['jumlah_tambah']) ? (int)$_POST['jumlah_tambah'] : 0;
    if ($id < 1 || $jumlah < 1) { $msg = 'Jumlah stok tambahan harus minimal 1.'; $msg_type = 'danger'; }
    else {
        $q = $pdo->prepare('UPDATE products SET stok = stok + ? WHERE id = ?');
        $q->execute(array($jumlah, $id));
        if ($q->rowCount()) { header('Location: products.php?msg=stock_added'); exit; }
        $msg = 'Menu tidak ditemukan atau stok tidak berubah.'; $msg_type = 'warning';
    }
}
if (isset($_GET['del'])) { $pdo->prepare('DELETE FROM products WHERE id=?')->execute(array((int)$_GET['del'])); header('Location: products.php?msg=deleted'); exit; }
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'added') $msg = 'Menu berhasil ditambahkan.';
    elseif ($_GET['msg'] === 'stock_added') $msg = 'Stok berhasil ditambahkan.';
    elseif ($_GET['msg'] === 'deleted') $msg = 'Menu berhasil dihapus.';
}
$cats = $pdo->query('SELECT * FROM categories WHERE status=1')->fetchAll(PDO::FETCH_ASSOC);
$rows = $pdo->query('SELECT p.*,c.nama_kategori FROM products p JOIN categories c ON c.id=p.category_id ORDER BY (p.stok=0) DESC,(p.stok<=p.stok_minimum) DESC,p.nama_produk')->fetchAll(PDO::FETCH_ASSOC);
$habis = 0; $menipis = 0;
foreach ($rows as $r) { if ((int)$r['stok'] <= 0) $habis++; elseif ((int)$r['stok'] <= (int)$r['stok_minimum']) $menipis++; }
require '../config/header.php';
?>
<div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><h2 class="page-title mb-1">Menu & Stok</h2><span class="text-muted">Pantau persediaan dan tambah stok tanpa membuat menu baru.</span></div></div>
<?php if ($msg): ?><div class="alert alert-<?=htmlspecialchars($msg_type)?> alert-dismissible fade show" role="alert"><?=htmlspecialchars($msg)?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button></div><?php endif; ?>
<div class="row g-3 mb-3">
<div class="col-md-4"><div class="card p-3"><small class="text-muted fw-bold">TOTAL MENU</small><h3 class="mb-0 mt-2"><?=count($rows)?></h3></div></div>
<div class="col-md-4"><div class="card p-3 border-danger"><small class="text-danger fw-bold">STOK HABIS</small><h3 class="mb-0 mt-2 text-danger"><?=$habis?></h3></div></div>
<div class="col-md-4"><div class="card p-3 border-warning"><small class="text-warning-emphasis fw-bold">STOK MENIPIS</small><h3 class="mb-0 mt-2 text-warning-emphasis"><?=$menipis?></h3></div></div>
</div>
<?php if ($habis > 0 || $menipis > 0): ?><div class="alert alert-warning"><strong>Perhatian persediaan:</strong><?php if ($habis > 0): ?> Ada <?=$habis?> menu yang stoknya habis.<?php endif; ?><?php if ($menipis > 0): ?> Ada <?=$menipis?> menu yang stoknya menipis.<?php endif; ?> Tambahkan stok melalui kolom aksi pada tabel di bawah.</div><?php else: ?><div class="alert alert-success">Semua menu masih memiliki stok di atas batas minimum.</div><?php endif; ?>
<div class="card p-3 mb-4"><h5 class="page-title mb-3">Tambah Menu Baru</h5>
<form method="post" class="row g-2 align-items-end">
<div class="col-lg-2 col-md-4"><label class="form-label">Kode</label><input class="form-control" name="kode" placeholder="CF003" required></div>
<div class="col-lg-2 col-md-4"><label class="form-label">Nama menu</label><input class="form-control" name="nama" placeholder="Nama menu" required></div>
<div class="col-lg-2 col-md-4"><label class="form-label">Kategori</label><select class="form-select" name="category" required><?php foreach($cats as $c): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['nama_kategori'])?></option><?php endforeach; ?></select></div>
<div class="col-lg-2 col-md-3"><label class="form-label">Harga jual</label><input type="number" min="0" class="form-control" name="harga" placeholder="25000" required></div>
<div class="col-lg-1 col-md-3"><label class="form-label">HPP</label><input type="number" min="0" class="form-control" name="pokok" placeholder="12000" required></div>
<div class="col-lg-1 col-md-3"><label class="form-label">Stok awal</label><input type="number" min="0" class="form-control" name="stok" value="0" required></div>
<div class="col-lg-1 col-md-3"><label class="form-label">Min.</label><input type="number" min="0" class="form-control" name="min" value="5" required></div>
<div class="col-lg-1 col-md-12"><button name="add" class="btn btn-primary w-100">Tambah</button></div>
</form></div>
<div class="card p-3"><h5 class="page-title mb-3">Daftar Stok Menu</h5><div class="table-responsive"><table class="table align-middle">
<thead><tr><th>Kode</th><th>Menu</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Batas minimum</th><th>Status</th><th style="min-width:245px">Tambah stok</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($rows as $r): $stock=(int)$r['stok']; $minimum=(int)$r['stok_minimum']; ?><tr>
<td><?=htmlspecialchars($r['kode_produk'])?></td><td><strong><?=htmlspecialchars($r['nama_produk'])?></strong></td><td><?=htmlspecialchars($r['nama_kategori'])?></td><td><?=rupiah($r['harga_jual'])?></td><td class="<?=$stock <= $minimum ? 'low' : ''?>"><strong><?=$stock?></strong></td><td><?=$minimum?></td>
<td><?php if($stock <= 0): ?><span class="badge bg-danger">Stok Habis</span><?php elseif($stock <= $minimum): ?><span class="badge bg-warning text-dark">Stok Menipis</span><?php else: ?><span class="badge bg-success">Aman</span><?php endif; ?></td>
<td><form method="post" class="d-flex gap-2"><input type="hidden" name="product_id" value="<?=$r['id']?>"><input type="number" min="1" name="jumlah_tambah" class="form-control form-control-sm" placeholder="Jumlah" required style="max-width:100px"><button name="add_stock" class="btn btn-sm btn-success text-nowrap">+ Stok</button></form></td>
<td><a class="btn btn-sm btn-outline-danger" href="?del=<?=$r['id']?>" onclick="return confirm('Yakin ingin menghapus menu ini?')">Hapus</a></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="9" class="text-center text-muted">Belum ada menu.</td></tr><?php endif; ?></tbody></table></div></div>
<?php require '../config/footer.php'; ?>
