<?php
$host='localhost';$db='kafe_pos';$user='root';$pass='';
try{$pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);}
catch(PDOException $e){die('Koneksi database gagal: '.$e->getMessage());}
if(session_status()===PHP_SESSION_NONE) session_start();
function require_login(){if(empty($_SESSION['user'])){header('Location: /kafe_pos/index.php');exit;}}
function require_admin(){require_login();if($_SESSION['user']['role']!=='admin'){http_response_code(403);die('Akses ditolak');}}
function rupiah($n){return 'Rp '.number_format((float)$n,0,',','.');}
?>
